#ifndef _405_dimm_h_
#define _405_dimm_h_
long int walnut_dimm(void);
#endif
