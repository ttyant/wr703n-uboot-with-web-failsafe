/************************************************
 * NAME                 arm926ejs.h             *
 * Version      :       23 June 2003            *
 ************************************************/
/* Currently empty */
#ifndef __ARM926EJS_H__
#define __ARM926EJS_H__
#endif /*__ARM926EJS_H__*/
